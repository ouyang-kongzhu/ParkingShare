from getresultreport.get_report import TestReport
from  tools.util import FileUtil
from  tools.lib_util import APIUtil
from parameterized import parameterized
import unittest
class TestSalesAPI(unittest.TestCase):
    def setUp(self) -> None:
        pass
    def tearDown(self) -> None:
        pass
    @parameterized.expand(FileUtil.get_test_info('..\\conf\\test_info.ini', 'api_lessor', 'lessor_api'))
    def test_lessor(self,mothed,url,data,expect):


        a=APIUtil.assert_api(mothed,url,data,expect)


if __name__ == '__main__':

    TestSalesAPI().test_lessor()
    # TestReport('test_result').generate_html_report('v2.0')