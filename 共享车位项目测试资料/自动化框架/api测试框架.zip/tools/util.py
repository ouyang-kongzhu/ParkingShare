import configparser
import os
import time

class TimeUtil:
    @classmethod
    def get_filename_time(cls):
        """
           返回用于文件名格式的时间字符串
       :param :

       :return:
           时间字符串格式为%Y%m%d_%H%M%S
       """
        return time.strftime('%Y%m%d_%H%M%S', time.localtime())

    @classmethod
    def get_standard_format_time(cls):
        """
        获取当前系统时间，返回标准格式时间
        :return: 返回的时间格式为%Y-%m-%d %H:%M:%S
        """

        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())

class LogUtil:

    logger = None

    @classmethod
    def get_logger(cls, name):
        """
            返回规定格式的日志生成器对象
        :param name:
            调用logger的模块名
        :return:
            日志生成器对象
        """
        import logging
        if cls.logger is None:
            # 获取日志生成器对象
            cls.logger = logging.getLogger(name)
            # 定义获取信息的级别
            cls.logger.setLevel(level=logging.INFO)
            # 如果日志目录不存在则创建
            if not os.path.exists('..\\logs'):
                os.mkdir('..\\logs')
            # 创建logger的文件句柄与规定的文件关联
            handler = logging.FileHandler(
                '..\\logs\\' + TimeUtil.get_filename_time() + '.log', encoding='utf8')
            # 定义信息的格式
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            cls.logger.addHandler(handler)
            cls.logger.info(
                '*****************************************************\n')

        return cls.logger

class FileUtil:
    logger = LogUtil.get_logger(os.path.join(os.getcwd(), 'util'))
    @classmethod
    def get_ini_value(cls, path, section, option):
        """
        从ini配置文件中读取某个指定的键对应的值并返回
        :param path:配置文件路径
        :param section:节点名称
        :param option:键的名称
        :return:对应的单值
        """
        import configparser
        cp = configparser.RawConfigParser()
        value = None
        try:
            cp.read(path, encoding='utf-8')
            value = cp.get(section, option)
        except BaseException:
            cls.logger.error('读取配置文件错误')
        return value

    @classmethod
    def get_test_info(cls, path, section, option):
        """
        从test_info.ini读取excel配置信息，将excel内容全部读出
        :param path:测试信息配置文件路径及文件名
        :param section: 页面名称
        :param option: 每条测试信息的键
        :return: 测试信息的json格式
        """
        params = eval(cls.get_ini_value(path, section, option))
        import xlrd

        workbook = xlrd.open_workbook(params['test_info_path'])
        sheet_content = workbook.sheet_by_name(params['sheet_name'])
        case_sheet_content = workbook.sheet_by_name(params['case_sheet_name'])
        version = case_sheet_content.cell(1, 1).value
        test_data = []

        for i in range(params['start_row'], params['end_row']):
            expect = sheet_content.cell(i, params['expect_col']).value
            data = sheet_content.cell(i, params['test_data_col']).value
            di = []
            di.append(sheet_content.cell(i, params['request_method']).value)
            di.append(sheet_content.cell(i, params['uri']).value)
            request_params = {}  # 用于保存发送接口传递的参数
            if data :

                temp = str(data).split('\n')

                for t in temp:

                    request_params[t.split('=')[0]] = t.split('=')[1]
                di.append(request_params)
            else:
                request_params=None
                di.append(request_params)
            di.append(expect)
            di2=tuple(di)
            test_data.append(di2)


            # di['expect'] = expect
            # di['caseid'] = sheet_content.cell(i, params['caseid_col']).value
            # di['module'] = sheet_content.cell(i, params['module_col']).value
            # di['type'] = sheet_content.cell(i, params['type_col']).value
            # di['desc'] = sheet_content.cell(i, params['desc_col']).value
            # di['version'] = version
            # di['uri'] = sheet_content.cell(i, params['uri']).value
            # di['request_method'] = sheet_content.cell(i, params['request_method']).value
            # test_data.append(di)

        return test_data

class DBUtil:

    # 该类包含数据库连接方法，查询单条数据方法，查询多条数据方法和增删改方法
    logger = LogUtil.get_logger(os.path.join(os.getcwd(), 'util'))
    def __init__(self,option):
        self.db_info = eval(
            FileUtil.get_ini_value(
                '..\\conf\\base.ini',
                'mysql',
                f'{option}'))

    def get_conn(self):
        """
        连接数据库返回数据库连接对象
        :param db_info:数据库配置信息
        :return:数据库连接对象
        """
        import pymysql
        conn = None
        try:

            conn = pymysql.connect(
                host=self.db_info[0],
                database=self.db_info[1],
                user=self.db_info[2],
                password=self.db_info[3],
                charset=self.db_info[4])
        except BaseException:
             DBUtil.logger.error('数据库连接失败')
        finally:
            return conn


    def query_one(self, sql):
        """
        查询一条结果
        :param sql: 查询语句
        :return: 单条结果集，以元组方式返回
        """

        conn = self.get_conn()
        cur = conn.cursor()
        result = None
        try:
            cur.execute(sql)
            result = cur.fetchone()
        except BaseException:
            DBUtil.logger.error('查询失败')
        finally:
            cur.close()
            conn.close()
            return result


    def query_all(self, sql):
        """
        查询多条结果
        :param sql: 查询语句
        :return: 多条结果集，以二维元组方式返回
        """

        conn = self.get_conn()
        cur = conn.cursor()
        result = None
        try:
            cur.execute(sql)
            result = cur.fetchall()
        except BaseException:
            DBUtil.logger.error('查询失败')
        finally:
            cur.close()
            conn.close()
            return result


    def update_db(self, sql):
        """
        增删改操作
        :param sql: DML语句
        :return:执行成功或失败的标记
        """
        flag = True

        conn = self.get_conn()
        cur = conn.cursor()
        try:
            cur.execute(sql)
            conn.commit()
        except BaseException:
            flag = False
            DBUtil.logger.error('sql执行失败')
        finally:
            cur.close()
            conn.close()
            return flag

if __name__ == '__main__':
    test_info = FileUtil.get_test_info('..\\conf\\test_info.ini', 'api_lessor', 'lessor_api')
    print(test_info)



